
clc,clear;
load('one_k_means_parameter.mat');
idx=k_means_parameter.newidx;
segdata=k_means_parameter.segdata;
newCent=k_means_parameter.newCent;



for k=1:3;
    for win = 1:size(idx,1)
        occu(win,k) = length(find(idx(win,:) == k))/size(idx,2);
    end  
    
    for sub = 1:27
       occupersub(k,sub) = length(find(idx(:,sub) == k))/size(idx,1);
    end    
    
    overallOccu(k) = length(find(idx == k))/numel(idx);
end
occur_sub=occupersub';
occur_time=occu;
occur_overall=overallOccu;

[p,table] = anova_rm(occur_sub,0);
save('occur_persub.mat','occur_sub');
