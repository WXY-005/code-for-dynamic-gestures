clc,clear

for i1 = 1:27 
load('State1.mat'); A{i1} = real(State1{i1,1});
load('Base.mat'); N{i1} = real(Ws{i1,1});

end



for j = 1:13
        for k = 1:13
         
            for isub =1:27 %isub
                
              ALL(isub) = A{isub}(j,k);
              NO(isub) = N{isub}(j,k);
     
            end
            
            test=[ALL;NO];
           test=test';
           test(isnan(test))=0
           
           
           
           mA=mean(ALL);
           mN=mean(NO);
         
           [p,table] = anova_rm(test,0);
           P(j,k)=p(1);
           F(j,k)=table{2,5};
            
           

          
                  
        end
end

    xlswrite('State1_FC',P,1);
    xlswrite('State1_FC',F,2);
    
%     [m,n]=find(P<0.05);
%     S1=[m,n];
%     
    %%FDR
  
    P1=P(:);
    [pthr,pcor,padj] = fdr(P1);
    P_fdr=reshape(pcor,13,13);

    [m,n]=find(P_fdr<0.05); 
    A =[m,n];
     xlswrite('State1_FC',P_fdr,3);
      xlswrite('State1_FC',A,4);
      
    
      load('state_cent.mat');
      S1=state{1,1};
      N=13;
      Ma = ones(N,N)*0;
      for i=1:length(A);
          m=A(i,1);
          n=A(i,2);
          Ma(m,n)=S1(m,n);
      end
      
      %% S2
      clc,clear

for i1 = 1:27 
load('State2.mat'); A{i1} = real(State2{i1,1});
load('Base.mat'); N{i1} = real(Ws{i1,1});

end



for j = 1:13
        for k = 1:13
            
            for isub =1:27 
                
              ALL(isub) = A{isub}(j,k);
              NO(isub) = N{isub}(j,k);
     
            end
            
            test=[ALL;NO];
           test=test';
           test(isnan(test))=0
           
           
           
           mA=mean(ALL);
           mN=mean(NO);
         
           [p,table] = anova_rm(test,0);
           P(j,k)=p(1);
           F(j,k)=table{2,5};
            
           

          
                  
        end
end

    xlswrite('State2_FC',P,1);
    xlswrite('State2_FC',F,2);
    
%     [m,n]=find(P<0.05);
%     S2=[m,n];
%     
    %%FDR
  
    P1=P(:);
    [pthr,pcor,padj] = fdr(P1);
    P_fdr=reshape(pcor,13,13);

    [m,n]=find(P_fdr<0.05);
    A =[m,n];
    xlswrite('State2_FC',P_fdr,3);
     xlswrite('State2_FC',A,4);
      
      %%
    clc,clear

for i1 = 1:27 
load('State3.mat'); A{i1} = real(State3{i1,1});
load('Base.mat'); N{i1} = real(Ws{i1,1});

end



for j = 1:13
        for k = 1:13
           
            for isub =1:27 
                
              ALL(isub) = A{isub}(j,k);
              NO(isub) = N{isub}(j,k);
     
            end
            
            test=[ALL;NO];
           test=test';
           test(isnan(test))=0
           
           
           
           mA=mean(ALL);
           mN=mean(NO);
         
           [p,table] = anova_rm(test,0);
           P(j,k)=p(1);
           F(j,k)=table{2,5};
            
           

          
                  
        end
end

    xlswrite('State3_FC',P,1);
    xlswrite('State3_FC',F,2);
    
%    [m,n]=find(P<0.05);
%     S3=[m,n];
    %%FDR
  
    P1=P(:);
    [pthr,pcor,padj] = fdr(P1);
    P_fdr=reshape(pcor,13,13);

    [m,n]=find(P_fdr<0.05);
    A =[m,n];
     xlswrite('State3_FC',P_fdr,3);
      xlswrite('State3_FC',A,4);  
 