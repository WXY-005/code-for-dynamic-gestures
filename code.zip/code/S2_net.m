
clc,clear
load('State2.mat');

    
for i=1:27  
    m=find(State2{i,1}<0);
    State2{i,1}(m)=0;
    
    State2{i,1}(isnan(State2{i,1})) = 0
    State2{i,1}(isinf(State2{i,1}))=0
    State2{i,1}=real(State2{i,1})
 end;

%  check if there are some data small than zero 
 for i=1:27
    Nm=find(State2{i,1}<0);
    Nm2=find(State2{i,1}(isnan(State2{i,1})))
   
    State2{i,1}=real(State2{i,1})
    
    
 end
 Sparstiy_Def=cell(27,1);
 
 for i=1:27
   
    
    Rmatrix=State2{i,1};
     [Rmax Smin Kmin] = gretna_get_rmax (Rmatrix);
   Sparstiy_Def{i}=  [Rmax Smin Kmin]; 
    
    end

 

s1=0.2;   
s2=0.5;   
deltas=0.01;
n=100;
Thres_type='s';
[net] = gretna_sw_batch_networkanalysis_weight(State2, s1, s2, deltas, n, Thres_type);
 save('state2_net.mat','net')

