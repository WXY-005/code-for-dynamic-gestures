clc,clear
load('state1_net.mat');
s1_gE=net.agE';

load('state2_net.mat');
s2_gE=net.agE';

load('state3_net.mat');
s3_gE=net.agE';


test=[s1_gE,s2_gE,s3_gE];
[p,table] = anova_rm(test,0);
P_gE=p(1);
M_gE=mean(test,1);
%%

load('state1_net.mat');
s1_Cp=net.aCp';

load('state2_net.mat');
s2_Cp=net.aCp';

load('state3_net.mat');
s3_Cp=net.aCp';



test=[s1_Cp,s2_Cp,s3_Cp];
[p,table] = anova_rm(test,0);
P_cp=p(1);
M_cp=mean(test,1);

%%


load('state1_net.mat');
s1_Lp=net.aLp';

load('state2_net.mat');
s2_Lp=net.aLp';

load('state3_net.mat');
s3_Lp=net.aLp';


test=[s1_Lp,s2_Lp,s3_Lp];
[p,table] = anova_rm(test,0);
P_Lp=p(1);
M_Lp=mean(test,1);

