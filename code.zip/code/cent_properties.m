clc,clear;
load('one_k_means_parameter.mat');
idx=k_means_parameter.newidx;
segdata=k_means_parameter.segdata;
newCent=k_means_parameter.newCent;

N=13; %roi

for isub = 1:27
    sub=idx(:,isub);
    a=find(sub==1);
    Data=mean(segdata(a,:,isub),1);
    A = tril(ones(N,N));
    A(find(A)) = Data;
    B = A+triu(A',1);
    State1{isub,:}=B;
end

for isub = 1:27
    sub=idx(:,isub);
    a=find(sub==2);   
    Data=mean(segdata(a,:,isub),1);
    A = tril(ones(N,N));
    A(find(A)) = Data;
    B = A+triu(A',1);
    State2{isub,:}=B; %%
end

for isub = 1:27
    sub=idx(:,isub);
    a=find(sub==3);   
    Data=mean(segdata(a,:,isub),1);
    A = tril(ones(N,N));
    A(find(A)) = Data;
    B = A+triu(A',1);
    State3{isub,:}=B; 
end

% for isub = 1:27
%     sub=idx(:,isub);
%     a=find(sub==4);   
%     Data=mean(segdata(a,:,isub),1);
%     A = tril(ones(N,N));
%     A(find(A)) = Data;
%     B = A+triu(A',1)
%     State4{isub,:}=B;  
% end

save('State1.mat','State1');
save('State2.mat','State2');
save('State3.mat','State3');
% save('State4.mat','State4');


for k=1:3   
Data = newCent(k,:);%statek
A = tril(ones(N,N));
A(find(A)) = Data;

B = A+triu(A',1);
state{k}=B;
end
save('state_cent.mat','state');
