
clc,clear
load('State3.mat');


    
for i=1:27  %��������
    m=find(State3{i,1}<0);
    State3{i,1}(m)=0;
    
    State3{i,1}(isnan(State3{i,1})) = 0
    State3{i,1}(isinf(State3{i,1}))=0
    State3{i,1}=real(State3{i,1})
 end;

%  check if there are some data small than zero 
 for i=1:27
    Nm=find(State3{i,1}<0);
    Nm2=find(State3{i,1}(isnan(State3{i,1})))
   
    State3{i,1}=real(State3{i,1})
    
    
 end
 Sparstiy_Def=cell(27,1);
 
 for i=1:27
   
    
    Rmatrix=State3{i,1};
     [Rmax Smin Kmin] = gretna_get_rmax (Rmatrix);
   Sparstiy_Def{i}=  [Rmax Smin Kmin]; 
    
    end

 

s1=0.2;   %
s2=0.5;   %
deltas=0.01;
n=100;
Thres_type='s';
[net] = gretna_sw_batch_networkanalysis_weight(State3, s1, s2, deltas, n, Thres_type);
 save('state3_net.mat','net')

