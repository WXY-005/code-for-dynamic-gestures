clc,clear;
 load('cen_all.mat');
% load('cen_allsub.mat');
load('ONE_interbrain.mat'); 

Fs = 10;
duration=2400; 
window = round(26*Fs);    
overlap = round(1*Fs);   
segment = 1:overlap:duration-window;

% Get the segmented data in each window
for ii = 1:numel(segment)
    segdata(ii,:,:) = mean(data([segment(ii):segment(ii)+window],:,:));    
end


% Perform k-mean cluster at group level
ibsdata = mean(segdata, 3);





%%
centroid = newCent; 
cluster = 3; %%��һ�������״̬

for i = 1:size(segdata,3)
        [newidx(:,i), centt(:,:,i)] = kmeans(segdata(:,:,i), cluster,'MaxIter', 500,'Distance','cityblock', 'Start', centroid );
end

% Plot for visualization
figure,
plot(newidx,'LineWidth', 4); ylim([0  6]);yticks([[] 1:4 []]) %%

k_means_parameter={};
k_means_parameter.newidx=newidx;
k_means_parameter.newCent=newCent;
k_means_parameter.segdata=segdata;
save('one_k_means_parameter.mat','k_means_parameter');