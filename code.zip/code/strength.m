clc,clear

%% strength��ȡ
load('State1.mat');
load('State2.mat');
load('State3.mat');

%% r to z
for k=1:27
     a1=State1{k};
     a1=0.5*log((1+a1)./(1-a1));
     State1{k,1}=a1;
end

for k=1:27
     a1=State2{k};
     a1=0.5*log((1+a1)./(1-a1));
     State2{k,1}=a1;
end

for k=1:27
     a1=State3{k};
     a1=0.5*log((1+a1)./(1-a1));
     State3{k,1}=a1;
end


%% strength
for r = 1:13
for i=1:27
    s1{r,1}(i,1)=sum(State1{i,1}(:,r));
    strength1(r)=mean(s1{r,1},1);
end
end

save('s1_strength.mat','s1');

for r = 1:13
for i=1:27
    s2{r,1}(i,1)=sum(State2{i,1}(:,r));
    strength2(r)=mean(s2{r,1},1);
end
end
save('s2_strength.mat','s2');

for r = 1:13
for i=1:27
    s3{r,1}(i,1)=sum(State3{i,1}(:,r));
    strength3(r)=mean(s3{r,1},1);
end
end
save('s3_strength.mat','s3');

Strength=[strength1;strength2;strength3];
%% ����
for r=1:13
    test(:,1)=s1{r}(:);
    test(:,2)=s2{r}(:);
    test(:,3)=s3{r}(:);
    [p,table] = anova_rm(test,0);
    spss{r}=test;
    P(r,1)=p(1);
end
[pthr,pcor,padj] = fdr(P);
