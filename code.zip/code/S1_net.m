
clc,clear
load('State1.mat');

Sparstiy_Def=cell(27,1);

 for i=1:27
   
    
    Rmatrix=State1{i,1};
     [Rmax Smin Kmin] = gretna_get_rmax (Rmatrix);
   Sparstiy_Def{i}=  [Rmax Smin Kmin]; 
    
 end
    
for i=1:27  %��������
    m=find(State1{i,1}<0);
    State1{i,1}(m)=0;
    
    State1{i,1}(isnan(State1{i,1})) = 0
    State1{i,1}(isinf(State1{i,1}))=0
    State1{i,1}=real(State1{i,1})
 end;

%  check if there are some data small than zero 
 for i=1:27
    Nm=find(State1{i,1}<0);
    Nm2=find(State1{i,1}(isnan(State1{i,1})))
   
    State1{i,1}=real(State1{i,1})
    
    
 end
 Sparstiy_Def=cell(27,1);
 
 for i=1:27
   
    
    Rmatrix=State1{i,1};
     [Rmax Smin Kmin] = gretna_get_rmax (Rmatrix);
   Sparstiy_Def{i}=  [Rmax Smin Kmin]; 
    
    end

 

s1=0.2;   
s2=0.5;   
deltas=0.01;
n=100;
Thres_type='s';
[net] = gretna_sw_batch_networkanalysis_weight(State1, s1, s2, deltas, n, Thres_type);
 save('state1_net.mat','net')

